<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>New Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>cf32d7b0-c173-4e7e-bb91-3dcc576c9a9d</testSuiteGuid>
   <testCaseLink>
      <guid>7fb63cc7-846f-491c-ae3d-82e1c85fbd8e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Invalid Date</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>694f2ea4-c01d-429b-9d9d-44bfa7655739</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/New Test Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>0a9779c8-73ef-484e-885b-1b3eef41d63a</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>b6012acd-bf3c-43cf-a5ee-77deda32f393</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Valid Test Case</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>5bb239ce-d638-4109-9cc9-f32327ed2b7f</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
