<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>uploaded_fileName</name>
   <tag></tag>
   <elementGuidId>e10ec753-603b-4cef-822e-c8470df8552a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='css-wwp6xx'][contains(.,'File attached: 2mb.txt with file size of 2.17 MB2mb.txt2.17 MB')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
