<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Thank you for filling out the form</name>
   <tag></tag>
   <elementGuidId>953bc819-09f6-4d4d-b2ed-48db3ccf1176</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div[2]/div[2]/div[2]/div/div/div/div/div/div/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.chakra-text.css-ah0vfz</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>3af92f91-a2c5-44b7-9ec8-ba30246a326e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>chakra-text css-ah0vfz</value>
      <webElementGuid>9a03c534-9e13-4ee6-b0ee-20360783efd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Thank you for filling out the form.</value>
      <webElementGuid>1eb5c7b9-b486-4686-8ed6-0878ce7217e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-1brywh5&quot;]/div[@class=&quot;css-1l2oahx&quot;]/div[@class=&quot;css-5iccig&quot;]/div[@class=&quot;css-exzcdt&quot;]/div[@class=&quot;css-1hfy08p&quot;]/div[@class=&quot;chakra-container css-p4xb9w&quot;]/div[@class=&quot;css-1vr2anf&quot;]/div[@class=&quot;chakra-stack css-5v0uek&quot;]/div[@class=&quot;css-j7qwjs&quot;]/div[@class=&quot;css-0&quot;]/h2[@class=&quot;chakra-text css-ah0vfz&quot;]</value>
      <webElementGuid>7788dd6a-bd2a-44a3-b564-06f2bfcb7866</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/div[2]/div[2]/div/div/div/div/div/div/h2</value>
      <webElementGuid>05b6e4bc-873d-4864-a0b3-c5026e5b919a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='You have successfully submitted your response for Technical Test Form.'])[1]/following::h2[1]</value>
      <webElementGuid>08136abf-7751-4e56-bc1d-8e0018f926e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Look for a lock ('])[1]/following::h2[1]</value>
      <webElementGuid>72f8f505-06b7-4b72-ae9b-d1dee227c40c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit another response'])[1]/preceding::h2[1]</value>
      <webElementGuid>2657c541-d99b-4fd7-88b1-e2eaa8d5970d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='How was your form filling experience today?'])[1]/preceding::h2[1]</value>
      <webElementGuid>2dcc966c-1710-4dde-84cc-4d90d3168551</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Thank you for filling out the form.']/parent::*</value>
      <webElementGuid>b638666b-664e-408a-9827-5cb1f32801ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>cd0cf0a9-4a40-4204-817b-67435d48d3bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Thank you for filling out the form.' or . = 'Thank you for filling out the form.')]</value>
      <webElementGuid>00b45f31-bfc6-4e49-b90e-02b2681f65d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
