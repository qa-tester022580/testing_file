<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Choose file</name>
   <tag></tag>
   <elementGuidId>ffbd2112-e319-44af-8be2-2610e0572769</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div[2]/div[4]/div/div/form/div/div/div[8]/div[2]/div/p/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.chakra-text.css-0 > a.chakra-link.css-17hnxff</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>eea04532-ad56-485a-b458-2f9e978dd6a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>chakra-link css-17hnxff</value>
      <webElementGuid>8f4c9d1c-52e8-47fa-ba2c-ed1cfad0887f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Choose file</value>
      <webElementGuid>8125c195-02c8-4ad0-9639-ed7dcfc67fcb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-1brywh5&quot;]/div[@class=&quot;css-1l2oahx&quot;]/div[@class=&quot;css-5iccig&quot;]/div[@class=&quot;css-exzcdt&quot;]/div[@class=&quot;css-1s5ocgd&quot;]/form[1]/div[@class=&quot;css-h9t2jw&quot;]/div[@class=&quot;chakra-stack css-16g1uvh&quot;]/div[@class=&quot;chakra-form-control css-1kxonj9&quot;]/div[@class=&quot;css-0&quot;]/div[@class=&quot;css-6fy7hu&quot;]/p[@class=&quot;chakra-text css-0&quot;]/a[@class=&quot;chakra-link css-17hnxff&quot;]</value>
      <webElementGuid>9e997b91-d3b4-4e8a-b4d2-0517bc018a04</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/div[4]/div/div/form/div/div/div[8]/div[2]/div/p/a</value>
      <webElementGuid>1ab01add-52ff-4227-a7fd-746db4228b81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Choose file')]</value>
      <webElementGuid>a1236112-aa0d-43f4-b0ae-78012a472ef3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MyInfo'])[8]/following::a[1]</value>
      <webElementGuid>7e373b6a-6b01-4111-bdce-531c7a6be226</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(optional)'])[1]/following::a[1]</value>
      <webElementGuid>6cfee7c4-01cc-4269-9ee6-63bede38cff8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(optional)'])[2]/preceding::a[1]</value>
      <webElementGuid>872381ab-1291-4565-8b27-d6967c1e6da2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Choose file']/parent::*</value>
      <webElementGuid>8b9547af-5c6c-460f-836d-ec954c4e8852</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a</value>
      <webElementGuid>d0268119-83f4-457c-a6e7-35b7809b4840</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Choose file' or . = 'Choose file')]</value>
      <webElementGuid>d2223825-e805-46e4-9257-525b4da91f4d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
